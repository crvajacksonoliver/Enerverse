#include "CraftPoll.h"

double ExampleClass::ExampleFunction()
{
	return 5.51;
}
