enum Status
{
	OK, FAILED
};

enum Material
{
	EARTH, ROCK, METAL
};

enum Tool
{
	SHOVEL
};

class Block
{
public:
	Block(Material mat, float hardness, Tool tool);
};

class BlockRegistry
{
public:
	static void RegisterBlocks();
	static Status RegisterBlock(Block& block);

	static char* PollData();
private:
};