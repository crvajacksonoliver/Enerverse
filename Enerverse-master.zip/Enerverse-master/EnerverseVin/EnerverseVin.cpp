#include "EnerverseVin.h"

GMEXPORT double testFunction()
{
	return ExampleClass::ExampleFunction();
}