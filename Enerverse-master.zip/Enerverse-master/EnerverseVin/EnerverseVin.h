#pragma once

#include "CraftPoll.h"

#define GMEXPORT extern "C" __declspec (dllexport)

GMEXPORT double testFunction();